<?php
	$boston = mysqli_connect("localhost","root","","pat_boston");
	$montreal = mysqli_connect("localhost","root","","pat_montreal");
	$newyork = mysqli_connect("localhost","root","","pat_newyork");
	$paris = mysqli_connect("localhost","root","","pat_paris");

	

?>